$(document).ready(function () {
	var 
		is_mobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent),
		countBlockTop = $(".left-part").offset().top,
		windowHeight = window.innerHeight,
		windowWidth  = window.innerWidth,
		show = true;

	$(".noUi-handle").on("click", function () {
	  $(this).width(50);
	});

	var rangeSlider = document.getElementById("slider-range");
	var moneyFormat = wNumb({
	  decimals: 0,
	  thousand: ",",
	  prefix: ""
	});

	noUiSlider.create(rangeSlider, {
	  start: [100000, 1000000],
	  step: 1,
	  range: {
		min: [100000],
		max: [1000000]
	  },
	  format: moneyFormat,
	  connect: true
	});
  
	// Set visual min and max values and also update value hidden form inputs
	rangeSlider.noUiSlider.on("update", function (values, handle) {
	  document.getElementById("slider-range-value1").innerHTML = values[0];
	  document.getElementById("slider-range-value2").innerHTML = values[1];
	  document.getElementsByName("min-value").value = moneyFormat.from(values[0]);
	  document.getElementsByName("max-value").value = moneyFormat.from(values[1]);
	});
    
    $(window).scroll(function() {
		if( !is_mobile ) {
	        var scrollTop = $(window).scrollTop();
    	    $(".site-header__content-wrapper").css("bottom", -scrollTop);
		}
    }); 
	
    $(window).click(function() {
		//Hide the menus if visible
		$(".navbar-item.has-dropdown").removeClass("is-active");
		$(".navbar__background").removeClass("is-active");
		$(".navbar-item.has-dropdown .navbar-dropdown").removeClass("is-active").css("display", "none");				
	});

    $(".navbar-item.has-dropdown").on("click", function(event){
		event.stopPropagation();

		var 
			nav_background = $(".navbar__background"),
			dropdown = $(this).find(".navbar-dropdown");
		if ($(this).hasClass("is-active")) {
			$(this).removeClass("is-active");
			nav_background.removeClass("is-active");
			dropdown.removeClass("is-active");		
		} else {
			$(this).addClass("is-active");
			nav_background.addClass("is-active");	
			dropdown.addClass("is-active");		
		}
	});

	$(".al_menu-switcher").on("click", function(event){
		let menu = $(this).parent().find(".al_menu-submenu");
		menu.addClass("is-active");
	});

	$(".al_menu-submenu-back").on("click", function(event){
		$(this).parent().removeClass("is-active");
	});

	const swiper = new Swiper('.swiper', {
		direction: 'horizontal',
		slidesPerView: "auto",
		slideClass: "cars-available-slide",
		loopedSlides: 3,
		loop: true,
	  
		navigation: {
		  nextEl: '.cars-available__slider-arrow-left',
		  prevEl: '.cars-available__slider-arrow-right',
		},
	});	
			
	$(window).scroll( function (){
		if(show && (countBlockTop - windowHeight < $(window).scrollTop() + windowHeight)){ 
			show = false;
					
			$('.left-part').spincrement({
				from: 1,
				duration: 3000,
				decimalPoint: ","
			});
		}
	})

});